create definer = root@localhost view inventory_value as
select rollup_group_item(`syos_db`.`items`.`state`, 0)                                      AS `state`,
       rollup_sum_switcher(count(0))                                                        AS `item_count`,
       rollup_sum_switcher(sum(`syos_db`.`items`.`quantity`))                               AS `total_quantity`,
       rollup_sum_switcher(sum((`syos_db`.`items`.`price` * `syos_db`.`items`.`quantity`))) AS `total_value`
from `syos_db`.`items`
where (`syos_db`.`items`.`state` not in ('EXPIRED', 'SOLD_OUT'))
group by `syos_db`.`items`.`state`
with rollup;

