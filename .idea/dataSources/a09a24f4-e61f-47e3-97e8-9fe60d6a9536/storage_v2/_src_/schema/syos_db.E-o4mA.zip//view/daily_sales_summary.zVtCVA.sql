create definer = root@localhost view daily_sales_summary as
select cast(`b`.`bill_date` as date)              AS `sale_date`,
       count(distinct `b`.`bill_number`)          AS `total_transactions`,
       sum(`b`.`total_amount`)                    AS `gross_revenue`,
       sum(`b`.`discount`)                        AS `total_discount`,
       sum((`b`.`total_amount` - `b`.`discount`)) AS `net_revenue`,
       count(distinct `bi`.`item_code`)           AS `unique_items_sold`,
       sum(`bi`.`quantity`)                       AS `total_items_sold`
from (`syos_db`.`bills` `b` left join `syos_db`.`bill_items` `bi` on ((`b`.`bill_number` = `bi`.`bill_number`)))
group by cast(`b`.`bill_date` as date);

