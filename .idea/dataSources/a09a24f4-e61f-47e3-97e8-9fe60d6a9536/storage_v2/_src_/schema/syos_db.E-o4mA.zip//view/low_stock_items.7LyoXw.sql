create definer = root@localhost view low_stock_items as
select `syos_db`.`items`.`code`     AS `code`,
       `syos_db`.`items`.`name`     AS `name`,
       `syos_db`.`items`.`quantity` AS `quantity`,
       `syos_db`.`items`.`state`    AS `state`,
       `syos_db`.`items`.`price`    AS `price`
from `syos_db`.`items`
where ((`syos_db`.`items`.`quantity` < 50) and (`syos_db`.`items`.`state` not in ('EXPIRED', 'SOLD_OUT')))
order by `syos_db`.`items`.`quantity`;

