create definer = root@localhost view v_user_role_distribution as
select `syos_db`.`users`.`role`                                              AS `role`,
       count(0)                                                              AS `user_count`,
       count((case when (`syos_db`.`users`.`is_active` = true) then 1 end))  AS `active_users`,
       count((case when (`syos_db`.`users`.`is_active` = false) then 1 end)) AS `inactive_users`
from `syos_db`.`users`
group by `syos_db`.`users`.`role`
order by field(`syos_db`.`users`.`role`, 'ADMIN', 'MANAGER', 'CASHIER', 'CUSTOMER');

