create definer = root@localhost view v_stock_conflict_report as
select `i`.`code`             AS `code`,
       `i`.`name`             AS `name`,
       count(`ol`.`id`)       AS `conflict_count`,
       max(`ol`.`created_at`) AS `last_conflict_time`
from (`syos_db`.`items` `i` left join `syos_db`.`operation_logs` `ol`
      on (((`ol`.`table_name` = 'items') and (`ol`.`record_id` = `i`.`code`) and (`ol`.`status` = 'CONFLICT'))))
where (`ol`.`created_at` >= (now() - interval 7 day))
group by `i`.`code`, `i`.`name`
having (`conflict_count` > 0)
order by `conflict_count` desc;

