create definer = root@localhost trigger tr_items_audit_update
    after update
    on items
    for each row
BEGIN
    INSERT INTO audit_log (table_name, record_id, action, old_values, new_values)
    VALUES (
               'items',
               OLD.code,
               'UPDATE',
               JSON_OBJECT(
                       'name', OLD.name,
                       'price', OLD.price,
                       'quantity_in_store', OLD.quantity_in_store,
                       'quantity_on_shelf', OLD.quantity_on_shelf,
                       'state', OLD.state
               ),
               JSON_OBJECT(
                       'name', NEW.name,
                       'price', NEW.price,
                       'quantity_in_store', NEW.quantity_in_store,
                       'quantity_on_shelf', NEW.quantity_on_shelf,
                       'state', NEW.state
               )
           );
END;

