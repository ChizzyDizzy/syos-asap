create
    definer = root@localhost procedure sp_update_stock_optimistic(IN p_item_code varchar(20), IN p_quantity_change int,
                                                                  IN p_expected_version int, IN p_user_id varchar(50),
                                                                  OUT p_success tinyint(1), OUT p_new_version int)
BEGIN
    DECLARE current_version INT;
    DECLARE current_qty INT;

    START TRANSACTION;

    SELECT version, quantity_on_shelf
    INTO current_version, current_qty
    FROM items
    WHERE code = p_item_code
        FOR UPDATE;

    IF current_version = p_expected_version THEN
        IF (current_qty + p_quantity_change) >= 0 THEN
            UPDATE items
            SET quantity_on_shelf = quantity_on_shelf + p_quantity_change,
                version = version + 1,
                last_modified_by = p_user_id,
                updated_at = CURRENT_TIMESTAMP
            WHERE code = p_item_code;

            SET p_success = TRUE;
            SET p_new_version = current_version + 1;

            COMMIT;
        ELSE
            SET p_success = FALSE;
            SET p_new_version = current_version;
            ROLLBACK;
        END IF;
    ELSE
        SET p_success = FALSE;
        SET p_new_version = current_version;
        ROLLBACK;
    END IF;
END;

