create
    definer = root@localhost procedure sp_create_sale_concurrent(IN p_sale_number varchar(50), IN p_cashier_id bigint,
                                                                 IN p_total_amount decimal(10, 2),
                                                                 IN p_discount decimal(10, 2),
                                                                 IN p_cash_tendered decimal(10, 2),
                                                                 IN p_change_amount decimal(10, 2), IN p_items json,
                                                                 OUT p_sale_id bigint, OUT p_success tinyint(1),
                                                                 OUT p_error_message varchar(500))
BEGIN
    DECLARE item_code VARCHAR(20);
    DECLARE item_qty INT;
    DECLARE item_price DECIMAL(10, 2);
    DECLARE current_stock INT;
    DECLARE i INT DEFAULT 0;
    DECLARE item_count INT;

    DECLARE CONTINUE HANDLER FOR SQLEXCEPTION
        BEGIN
            SET p_success = FALSE;
            SET p_error_message = 'Database error occurred during sale creation';
            ROLLBACK;
        END;

    SET p_success = TRUE;
    START TRANSACTION;

    INSERT INTO sales (
        sale_number, cashier_id, total_amount, discount,
        cash_tendered, change_amount, status, completed_at
    ) VALUES (
                 p_sale_number, p_cashier_id, p_total_amount, p_discount,
                 p_cash_tendered, p_change_amount, 'COMPLETED', NOW()
             );

    SET p_sale_id = LAST_INSERT_ID();
    SET item_count = JSON_LENGTH(p_items);

    process_items: WHILE i < item_count DO
            SET item_code = JSON_UNQUOTE(JSON_EXTRACT(p_items, CONCAT('$[', i, '].code')));
            SET item_qty = JSON_EXTRACT(p_items, CONCAT('$[', i, '].quantity'));
            SET item_price = JSON_EXTRACT(p_items, CONCAT('$[', i, '].price'));

            SELECT quantity_on_shelf INTO current_stock
            FROM items
            WHERE code = item_code
                FOR UPDATE;

            IF current_stock < item_qty THEN
                SET p_success = FALSE;
                SET p_error_message = CONCAT('Insufficient stock for item: ', item_code);
                ROLLBACK;
                LEAVE process_items;
            END IF;

            UPDATE items
            SET quantity_on_shelf = quantity_on_shelf - item_qty,
                version = version + 1,
                updated_at = CURRENT_TIMESTAMP
            WHERE code = item_code;

            INSERT INTO sale_items (sale_id, item_code, item_name, quantity, unit_price, subtotal)
            SELECT p_sale_id, code, name, item_qty, item_price, (item_qty * item_price)
            FROM items
            WHERE code = item_code;

            INSERT INTO stock_movements (item_code, movement_type, quantity, from_state, to_state, user_id, reference_id, reference_type, notes)
            VALUES (item_code, 'SALE', -item_qty, 'ON_SHELF', 'SOLD_OUT', p_cashier_id, p_sale_number, 'SALE', CONCAT('Sale: ', p_sale_number));

            SET i = i + 1;
        END WHILE process_items;

    IF p_success = TRUE THEN
        SET p_error_message = NULL;
        COMMIT;
    END IF;
END;

