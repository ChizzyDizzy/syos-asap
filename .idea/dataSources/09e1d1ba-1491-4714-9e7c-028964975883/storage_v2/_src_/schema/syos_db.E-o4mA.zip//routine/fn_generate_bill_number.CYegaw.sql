create
    definer = root@localhost function fn_generate_bill_number() returns varchar(50) deterministic
BEGIN
    DECLARE bill_count INT;
    DECLARE new_bill_number VARCHAR(50);

    SELECT COUNT(*) INTO bill_count FROM bills;
    SET new_bill_number = CONCAT('BILL', LPAD(bill_count + 1, 6, '0'));

    RETURN new_bill_number;
END;

