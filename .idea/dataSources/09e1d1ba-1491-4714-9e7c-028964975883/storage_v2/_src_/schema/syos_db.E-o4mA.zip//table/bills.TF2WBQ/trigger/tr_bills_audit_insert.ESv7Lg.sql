create definer = root@localhost trigger tr_bills_audit_insert
    after insert
    on bills
    for each row
BEGIN
    INSERT INTO audit_log (table_name, record_id, action, user_id, new_values)
    VALUES (
        'bills',
        NEW.bill_number,
        'INSERT',
        NEW.user_id_ref,
        JSON_OBJECT(
            'bill_number', NEW.bill_number,
            'total_amount', NEW.total_amount,
            'transaction_type', NEW.transaction_type
        )
    );
END;

