create
    definer = root@localhost procedure sp_expire_items()
BEGIN
    UPDATE items
    SET state = 'EXPIRED',
        quantity_on_shelf = 0,
        quantity_in_store = 0
    WHERE expiry_date < CURDATE()
      AND state != 'EXPIRED';

    INSERT INTO stock_movements (item_code, movement_type, quantity, from_state, to_state, notes)
    SELECT
        code,
        'EXPIRE',
        (quantity_in_store + quantity_on_shelf),
        state,
        'EXPIRED',
        'Auto-expired by system'
    FROM items
    WHERE expiry_date < CURDATE()
      AND state = 'EXPIRED'
      AND NOT EXISTS (
        SELECT 1 FROM stock_movements sm
        WHERE sm.item_code = items.code
          AND sm.movement_type = 'EXPIRE'
          AND DATE(sm.movement_date) = CURDATE()
    );
END;

