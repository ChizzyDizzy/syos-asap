create definer = root@localhost view v_low_stock_items as
select `syos_db`.`items`.`code`                                                          AS `code`,
       `syos_db`.`items`.`name`                                                          AS `name`,
       `syos_db`.`items`.`category`                                                      AS `category`,
       (`syos_db`.`items`.`quantity_in_store` + `syos_db`.`items`.`quantity_on_shelf`)   AS `total_quantity`,
       `syos_db`.`items`.`reorder_level`                                                 AS `reorder_level`,
       (`syos_db`.`items`.`reorder_level` -
        (`syos_db`.`items`.`quantity_in_store` + `syos_db`.`items`.`quantity_on_shelf`)) AS `units_needed`,
       `syos_db`.`items`.`price`                                                         AS `price`
from `syos_db`.`items`
where (((`syos_db`.`items`.`quantity_in_store` + `syos_db`.`items`.`quantity_on_shelf`) <
        `syos_db`.`items`.`reorder_level`) and (`syos_db`.`items`.`state` <> 'EXPIRED'))
order by (`syos_db`.`items`.`reorder_level` -
          (`syos_db`.`items`.`quantity_in_store` + `syos_db`.`items`.`quantity_on_shelf`)) desc;

