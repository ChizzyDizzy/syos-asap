create definer = root@localhost view v_concurrent_sales_stats as
select cast(`s`.`created_at` as date)   AS `sale_date`,
       hour(`s`.`created_at`)           AS `sale_hour`,
       count(distinct `s`.`id`)         AS `total_sales`,
       count(distinct `s`.`cashier_id`) AS `concurrent_cashiers`,
       sum(`s`.`total_amount`)          AS `total_revenue`,
       avg(`s`.`total_amount`)          AS `avg_sale_amount`,
       max(`s`.`created_at`)            AS `last_sale_time`
from `syos_db`.`sales` `s`
where (`s`.`status` = 'COMPLETED')
group by cast(`s`.`created_at` as date), hour(`s`.`created_at`);

