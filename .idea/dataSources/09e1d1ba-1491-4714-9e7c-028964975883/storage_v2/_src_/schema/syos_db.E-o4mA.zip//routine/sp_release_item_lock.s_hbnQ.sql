create
    definer = root@localhost procedure sp_release_item_lock(IN p_item_code varchar(20), IN p_user_id bigint)
BEGIN
    UPDATE items
    SET locked_by = NULL,
        lock_timestamp = NULL
    WHERE code = p_item_code
      AND locked_by = p_user_id;
END;

