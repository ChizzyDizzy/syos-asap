create
    definer = root@localhost procedure sp_acquire_item_lock(IN p_item_code varchar(20), IN p_user_id bigint,
                                                            OUT p_lock_acquired tinyint(1))
BEGIN
    DECLARE lock_owner BIGINT;
    DECLARE lock_time TIMESTAMP;

    SELECT locked_by, lock_timestamp
    INTO lock_owner, lock_time
    FROM items
    WHERE code = p_item_code
        FOR UPDATE;

    IF lock_owner IS NOT NULL AND TIMESTAMPDIFF(MINUTE, lock_time, NOW()) > 5 THEN
        SET lock_owner = NULL;
    END IF;

    IF lock_owner IS NULL OR lock_owner = p_user_id THEN
        UPDATE items
        SET locked_by = p_user_id,
            lock_timestamp = NOW()
        WHERE code = p_item_code;
        SET p_lock_acquired = TRUE;
    ELSE
        SET p_lock_acquired = FALSE;
    END IF;
END;

