create definer = root@localhost view v_daily_sales_summary as
select cast(`syos_db`.`bills`.`bill_date` as date)                            AS `sale_date`,
       count(0)                                                               AS `total_bills`,
       sum(`syos_db`.`bills`.`total_amount`)                                  AS `gross_revenue`,
       sum(`syos_db`.`bills`.`discount`)                                      AS `total_discounts`,
       sum((`syos_db`.`bills`.`total_amount` - `syos_db`.`bills`.`discount`)) AS `net_revenue`,
       avg(`syos_db`.`bills`.`total_amount`)                                  AS `avg_bill_amount`,
       count(distinct `syos_db`.`bills`.`user_id_ref`)                        AS `active_cashiers`
from `syos_db`.`bills`
where (`syos_db`.`bills`.`status` = 'COMPLETED')
group by cast(`syos_db`.`bills`.`bill_date` as date)
order by `sale_date` desc;

