create definer = root@localhost view v_cashier_performance as
select `u`.`user_id`            AS `user_id`,
       `u`.`username`           AS `username`,
       `u`.`full_name`          AS `full_name`,
       count(distinct `s`.`id`) AS `total_sales`,
       sum(`s`.`total_amount`)  AS `total_revenue`,
       avg(`s`.`total_amount`)  AS `avg_sale_amount`,
       min(`s`.`created_at`)    AS `first_sale`,
       max(`s`.`created_at`)    AS `last_sale`
from (`syos_db`.`users` `u` left join `syos_db`.`sales` `s` on ((`u`.`id` = `s`.`cashier_id`)))
where ((`u`.`role` in ('CASHIER', 'MANAGER', 'ADMIN')) and (`s`.`status` = 'COMPLETED'))
group by `u`.`user_id`, `u`.`username`, `u`.`full_name`
order by `total_revenue` desc;

