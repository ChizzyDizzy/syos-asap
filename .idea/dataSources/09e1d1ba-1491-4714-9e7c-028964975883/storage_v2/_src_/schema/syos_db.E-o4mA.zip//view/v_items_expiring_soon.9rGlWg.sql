create definer = root@localhost view v_items_expiring_soon as
select `syos_db`.`items`.`code`                                                        AS `code`,
       `syos_db`.`items`.`name`                                                        AS `name`,
       `syos_db`.`items`.`category`                                                    AS `category`,
       `syos_db`.`items`.`expiry_date`                                                 AS `expiry_date`,
       (to_days(`syos_db`.`items`.`expiry_date`) - to_days(curdate()))                 AS `days_remaining`,
       (`syos_db`.`items`.`quantity_in_store` + `syos_db`.`items`.`quantity_on_shelf`) AS `total_quantity`,
       `syos_db`.`items`.`price`                                                       AS `price`
from `syos_db`.`items`
where ((`syos_db`.`items`.`expiry_date` is not null) and
       ((to_days(`syos_db`.`items`.`expiry_date`) - to_days(curdate())) between 0 and 7) and
       (`syos_db`.`items`.`state` <> 'EXPIRED'))
order by `syos_db`.`items`.`expiry_date`;

